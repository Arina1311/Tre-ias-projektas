#include "Isvedimas.h"
#include <iostream>
#include <fstream>
#include <iomanip>

void RasymasIRezultatuFaila(const string& failoPavadinimas, char Pasirinkimas, const vector<Studentas>& grupe) {
    ofstream output(failoPavadinimas); // Kuriame nauja faila

    try {
        if (!output.is_open()) {
            throw runtime_error("Nepavyko sukurti failo su rezultatais.");
        }

        output << fixed << setprecision(2);
        output << left << setw(15) << "Vardas" << setw(15) << "Pavarde" << setw(20) << (Pasirinkimas == 'V' ? "Galutinis(Vid.)" : "Galutinis(Med.)") << setw(15) << "Egzaminas";
        output << setw(15) << "Pazymiai" << endl;
        output << "---------------------" << "---------------------" << "---------------------" << "---------------------" << std::endl;

        for (const auto& studentas : grupe) {
            output << left << setw(15) << studentas.Vardas << setw(15) << studentas.Pavarde << setw(20) << (Pasirinkimas == 'V' ? studentas.Vidurkis : studentas.Mediana) << setw(15) << studentas.Egzaminas;
            for (const auto& pazymys : studentas.NamuDarbai) {
                output << pazymys << " ";
            }
            output << endl;
        }

        output.close(); // Uždarome
        cout << "Rezultatai paruošti faile" << endl;
    } catch (const runtime_error& e) {
        cerr << e.what() << endl;
    }
}
