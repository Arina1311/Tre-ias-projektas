#ifndef ISVEDIMAS_H
#define ISVEDIMAS_H

#include <vector>
#include "duomenys.h"
#include <string>

void RasymasIRezultatuFaila(const string& failoPavadinimas, char Pasirinkimas, const vector<Studentas>& grupe);

#endif