#ifndef FAILONUSKAITYMAS_H
#define FAILONUSKAITYMAS_H

#include <vector>
#include <string>
#include "duomenys.h"

vector<Studentas> SkaitytiDuomenisIsFailo(const string& fileName);

#endif 
