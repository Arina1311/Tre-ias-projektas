#ifndef FAILONUSKAITYMAS_H
#define FAILONUSKAITYMAS_H

#include <list>
#include <string>
#include "duomenys.h"

list<Studentas> SkaitytiDuomenisIsFailo(const string& fileName, char Pasirinkimas);

#endif 
