var searchData=
[
  ['finalinis_0',['finalinis',['../duomenys_8cpp.html#a4618f5aebde9a44e4651429dc4e1b8df',1,'finalinis(double A[], double B[], double C[], double D[], double E[], int testavimask):&#160;duomenys.cpp'],['../duomenys_8h.html#a4618f5aebde9a44e4651429dc4e1b8df',1,'finalinis(double A[], double B[], double C[], double D[], double E[], int testavimask):&#160;duomenys.cpp']]]
];
