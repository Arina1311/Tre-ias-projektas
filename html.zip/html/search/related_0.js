var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_studentas.html#a448747727847d3e74e8f3639b6aa3d56',1,'Studentas']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_studentas.html#aa6d979f3b2d2212048b760d8bb9a7046',1,'Studentas']]]
];
