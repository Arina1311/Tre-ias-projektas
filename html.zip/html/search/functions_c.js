var searchData=
[
  ['vardas_0',['vardas',['../class_zmogus.html#a27a248ac6c61fa29d8f98383892f6ab8',1,'Zmogus::vardas()'],['../class_studentas.html#a8f087bcb62ff8c538fbb86adc7de9e56',1,'Studentas::vardas()']]],
  ['vidutiniai_1',['vidutiniai',['../duomenys_8cpp.html#a0b577f8ed7713cae6af7e283d7075118',1,'vidutiniai(double M[], int k):&#160;duomenys.cpp'],['../duomenys_8h.html#a0b577f8ed7713cae6af7e283d7075118',1,'vidutiniai(double M[], int k):&#160;duomenys.cpp']]]
];
