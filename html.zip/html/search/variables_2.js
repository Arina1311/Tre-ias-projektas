var searchData=
[
  ['vardas_0',['Vardas',['../class_zmogus.html#ad752feab373733e70e2101724e8d1d9d',1,'Zmogus']]]
];
