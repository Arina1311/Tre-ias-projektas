var searchData=
[
  ['informacija_0',['informacija',['../class_zmogus.html#a5526e6fefc56ccc370a9766e62e0232d',1,'Zmogus::informacija()'],['../class_studentas.html#ad2e8a624618a6d49415f348bf0052a98',1,'Studentas::informacija()']]],
  ['isvargsiukas_1',['isvargsiukas',['../duomenys_8cpp.html#a421d3ba3a557a9e598e2abdc77fae7c7',1,'isVargsiukas(const Studentas &amp;studentas):&#160;duomenys.cpp'],['../duomenys_8h.html#a421d3ba3a557a9e598e2abdc77fae7c7',1,'isVargsiukas(const Studentas &amp;studentas):&#160;duomenys.cpp']]]
];
