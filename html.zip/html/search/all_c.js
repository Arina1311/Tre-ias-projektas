var searchData=
[
  ['setegzaminas_0',['setEgzaminas',['../class_studentas.html#a8128f32f5761f415868d129a9f6436bf',1,'Studentas']]],
  ['setnamudarbai_1',['setNamuDarbai',['../class_studentas.html#a81f69ab219eedd3083c27739cf358238',1,'Studentas']]],
  ['setpavarde_2',['setpavarde',['../class_zmogus.html#a9eaa5730bd6d5eb6837b6b2461661834',1,'Zmogus::setpavarde()'],['../class_studentas.html#a66c1d3326b780dc96237fc4b7b040c1e',1,'Studentas::setPavarde(const string &amp;naujaPavarde)']]],
  ['setpazymys_3',['setPazymys',['../class_studentas.html#a20abaaafb8ec83269874b21c526cf1a2',1,'Studentas']]],
  ['setvardas_4',['setvardas',['../class_studentas.html#ae66675750e025957fb87936aadbd501a',1,'Studentas::setVardas()'],['../class_zmogus.html#aeee3721f12fbdb16c58ba023083cb676',1,'Zmogus::setvardas()']]],
  ['skaitytiduomenisisfailo_5',['skaitytiduomenisisfailo',['../_failo_nuskaitymas_8h.html#a046a1c70015a4d09f49088e4a70b99a9',1,'SkaitytiDuomenisIsFailo(const string &amp;fileName, char Pasirinkimas):&#160;FailoNuskaitymas.cpp'],['../_failo_nuskaitymas_8cpp.html#a046a1c70015a4d09f49088e4a70b99a9',1,'SkaitytiDuomenisIsFailo(const string &amp;fileName, char Pasirinkimas):&#160;FailoNuskaitymas.cpp']]],
  ['studentas_6',['studentas',['../class_studentas.html#ab459e995e8c9b24cdc9aec5b09a66539',1,'Studentas::Studentas()'],['../class_studentas.html#a1e20708eaade2cfacbae082237bc511e',1,'Studentas::Studentas(const string &amp;vardas, const string &amp;pavarde, const vector&lt; int &gt; &amp;nd, int egzaminas, float pazymys)'],['../class_studentas.html#aef0484fe46cf05746f8ffc0d083fcf3e',1,'Studentas::Studentas(const Studentas &amp;other)'],['../class_studentas.html',1,'Studentas']]]
];
