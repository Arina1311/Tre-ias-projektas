var searchData=
[
  ['galutinispazymis_0',['galutinispazymis',['../duomenys_8cpp.html#a18e5a8ba82db0150fe11984656dad137',1,'GalutinisPazymis(double suma, vector&lt; int &gt; &amp;duomenys, int egzaminas, char pasirinkimas):&#160;duomenys.cpp'],['../duomenys_8h.html#a18e5a8ba82db0150fe11984656dad137',1,'GalutinisPazymis(double suma, vector&lt; int &gt; &amp;duomenys, int egzaminas, char pasirinkimas):&#160;duomenys.cpp']]],
  ['getnd_1',['getND',['../class_studentas.html#a9d08681129b8d9280b6616671b90f720',1,'Studentas']]]
];
