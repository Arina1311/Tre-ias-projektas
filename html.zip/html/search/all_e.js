var searchData=
[
  ['zmogus_0',['zmogus',['../class_zmogus.html',1,'Zmogus'],['../class_zmogus.html#ac7034e8672e7feda0e3e1303a5336f2b',1,'Zmogus::Zmogus()']]]
];
