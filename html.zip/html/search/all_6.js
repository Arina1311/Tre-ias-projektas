var searchData=
[
  ['kurimasduomenu_0',['kurimasduomenu',['../_isvedimas_8cpp.html#a3c2954d4d0da40abb451fa00c7948547',1,'KurimasDuomenu(int &amp;StudSkaicius, int &amp;NDk):&#160;Isvedimas.cpp'],['../_isvedimas_8h.html#a0be355b8e57fa1b6e8940825cb73532f',1,'KurimasDuomenu(int &amp;Skaicius, int &amp;Kiekis):&#160;Isvedimas.cpp']]]
];
