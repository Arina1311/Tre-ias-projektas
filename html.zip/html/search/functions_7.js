var searchData=
[
  ['namudarbai_0',['namuDarbai',['../class_studentas.html#aa6c4b55e743b88786a4b470e4f6a82a8',1,'Studentas']]],
  ['ndprideti_1',['NDPrideti',['../class_studentas.html#a24dbc285e63b57f951f06eb2757073f5',1,'Studentas']]]
];
