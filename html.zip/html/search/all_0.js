var searchData=
[
  ['apskaiciuotigalutinipazymi_0',['ApskaiciuotiGalutiniPazymi',['../class_studentas.html#a43f209c6b7252c930e86cf3089e527c6',1,'Studentas']]]
];
