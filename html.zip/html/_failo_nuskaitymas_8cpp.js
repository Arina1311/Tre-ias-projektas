var _failo_nuskaitymas_8cpp =
[
    [ "SkaitytiDuomenisIsFailo", "_failo_nuskaitymas_8cpp.html#a046a1c70015a4d09f49088e4a70b99a9", null ]
];