var class_studentas =
[
    [ "Studentas", "class_studentas.html#ab459e995e8c9b24cdc9aec5b09a66539", null ],
    [ "Studentas", "class_studentas.html#a1e20708eaade2cfacbae082237bc511e", null ],
    [ "Studentas", "class_studentas.html#aef0484fe46cf05746f8ffc0d083fcf3e", null ],
    [ "~Studentas", "class_studentas.html#a63e449e0f51a0b14340d02ee71b4be23", null ],
    [ "ApskaiciuotiGalutiniPazymi", "class_studentas.html#a43f209c6b7252c930e86cf3089e527c6", null ],
    [ "egzaminas", "class_studentas.html#a8ec75244e6c21cf5a6af9f6d02f20fa2", null ],
    [ "getND", "class_studentas.html#a9d08681129b8d9280b6616671b90f720", null ],
    [ "informacija", "class_studentas.html#ad2e8a624618a6d49415f348bf0052a98", null ],
    [ "namuDarbai", "class_studentas.html#aa6c4b55e743b88786a4b470e4f6a82a8", null ],
    [ "NDPrideti", "class_studentas.html#a24dbc285e63b57f951f06eb2757073f5", null ],
    [ "operator=", "class_studentas.html#a25bcc531503d3bc490dab4a656e3b8e9", null ],
    [ "pavarde", "class_studentas.html#a11320252edec65efce7fc03b6082b9c2", null ],
    [ "pazymys", "class_studentas.html#a851f3c5b3fbf171a2354dc21a6378aac", null ],
    [ "setEgzaminas", "class_studentas.html#a8128f32f5761f415868d129a9f6436bf", null ],
    [ "setNamuDarbai", "class_studentas.html#a81f69ab219eedd3083c27739cf358238", null ],
    [ "setPavarde", "class_studentas.html#a66c1d3326b780dc96237fc4b7b040c1e", null ],
    [ "setPazymys", "class_studentas.html#a20abaaafb8ec83269874b21c526cf1a2", null ],
    [ "setVardas", "class_studentas.html#ae66675750e025957fb87936aadbd501a", null ],
    [ "vardas", "class_studentas.html#a8f087bcb62ff8c538fbb86adc7de9e56", null ],
    [ "operator<<", "class_studentas.html#a448747727847d3e74e8f3639b6aa3d56", null ],
    [ "operator>>", "class_studentas.html#aa6d979f3b2d2212048b760d8bb9a7046", null ]
];