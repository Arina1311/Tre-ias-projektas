var duomenys_8cpp =
[
    [ "finalinis", "duomenys_8cpp.html#a4618f5aebde9a44e4651429dc4e1b8df", null ],
    [ "GalutinisPazymis", "duomenys_8cpp.html#a18e5a8ba82db0150fe11984656dad137", null ],
    [ "isVargsiukas", "duomenys_8cpp.html#a421d3ba3a557a9e598e2abdc77fae7c7", null ],
    [ "palygintiPagalPavarde", "duomenys_8cpp.html#a2116d42634e6cb9f3e60a68cb39401f1", null ],
    [ "palygintiPagalPazymi", "duomenys_8cpp.html#a5316165e88ef4d1627860ff954441f9c", null ],
    [ "palygintiPagalVarda", "duomenys_8cpp.html#a3829ffcbdc96532bcd2696c01759271c", null ],
    [ "vidutiniai", "duomenys_8cpp.html#a0b577f8ed7713cae6af7e283d7075118", null ]
];