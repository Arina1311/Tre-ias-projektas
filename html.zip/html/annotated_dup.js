var annotated_dup =
[
    [ "Studentas", "class_studentas.html", "class_studentas" ],
    [ "Zmogus", "class_zmogus.html", "class_zmogus" ]
];